﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using MongoDB;
using MongoDB.Bson;
using MongoDB.Driver;

namespace UsandoMongoDB
{
    public partial class Painel : Form
    {
        IMongoCollection<BsonDocument> collection;
        IMongoDatabase db;
        MongoClient mongo;
        public Painel()
        {
            InitializeComponent();

            mongo = new MongoClient("mongodb://localhost:27017");
            db = mongo.GetDatabase("TesteDb");
            collection = db.GetCollection<BsonDocument>("Users");

            dgvUsers.Columns.Clear();
            dgvUsers.Columns.Add("_id", "#");
            dgvUsers.Columns.Add("name", "Nome");
            dgvUsers.Columns.Add("height", "Altura");
            dgvUsers.Columns.Add("email", "E-mail");
        }

        private void refreshView()
        {
            dgvUsers.Rows.Clear();

            foreach (var user in collection.Find(new BsonDocument()).ToList())
            {
                //txtViewCollection.Text = txtViewCollection.Text + Environment.NewLine + user["name"];
                dgvUsers.Rows.Add(user["_id"], user["name"], user["height"], user["email"]);
            }

            //dgvUsers.DataSource = collection.Find(new BsonDocument()).ToList();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            refreshView();
        }

        private void btnIncluir_Click(object sender, EventArgs e)
        {
            var document = new BsonDocument
                {
                    { "name", txtName.Text },
                    { "height", txtHeight.Text },
                    { "email", txtEmail.Text },
                    { "info", new BsonDocument
                        {
                            { "x", 203 },
                            { "y", 102 }
                        }}
                };

            collection.InsertOne(document);

            refreshView();
        }

        private void Painel_Load(object sender, EventArgs e)
        {
            refreshView();
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            //searchs equals text in txtIdUser
            //var filter = Builders<BsonDocument>.Filter.Eq("name", txtIdUser.Text.Trim());

            //searchs like text in txtIdUser
            //var filter = Builders<BsonDocument>.Filter.Regex("name", new BsonRegularExpression(txtIdUser.Text.Trim()));

            //var listDocs = collection.Find(new BsonDocument()).ToList();
            //var filteredsDocs = listDocs
            //    .Where(x => x["name"].ToString().ToLower().Contains(txtIdUser.Text.Trim().ToLower()));
            //var document = filteredsDocs.FirstOrDefault();

            var query_id = Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(txtIdUser.Text.Trim()));
            var document = collection.Find(query_id).FirstOrDefault();

            if (document != null)
            {
                txtNameUpdate.Text = document["name"].ToString();
                txtAlturaUpdate.Text = document["height"].ToString();
                txtEmailUpdate.Text = document["email"].ToString();
            }
            else
            {
                MessageBox.Show("Registro não encontrado");
            }

        }

        private void btnAlterarRegistro_Click(object sender, EventArgs e)
        {
            var query_id = Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(txtIdUser.Text.Trim()));
            var document = collection.Find(query_id).FirstOrDefault();

            if (document != null)
            {
                var update = Builders<BsonDocument>.Update.Set("name", txtNameUpdate.Text.Trim())
                    .Set("height", txtAlturaUpdate.Text.Trim())
                    .Set("email", txtEmailUpdate.Text.Trim()); // update modifiers
                collection.UpdateOne(query_id, update);

                refreshView();
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            var query_id = Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(txtIdUser.Text.Trim()));
            var document = collection.Find(query_id).FirstOrDefault();

            if (document != null)
            {
                // collection.DeleteOne(query_id);
                collection.FindOneAndDelete(document);

                refreshView();
            }
        }
    }
}
